package com.green.distribution.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class OrderProduct {
	private String orderNo;		// 주문번호
	private String productCd;	// 상품코드
	private int price;			// 판매가
	private int orderQty;		// 주문수량
	private int amount;			// 총액
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
	private Date orderDate;		// 발주일
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
	private Date requestDate;	// 납품요청일
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
	private Date addDate;		// 등록일
	private String remark;		// 비고
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Seoul")
	private Date stateDate;		// 최종변경일
	
//	join
	private String ename;	// 직원명
	private String pname;	// 상품명
	private String buyerCd;	// 구매자코드
	private String status;	// 상태
	private String unit;	// 단위
	
	
//	정렬
	private String sortBy;
	private String sortAs;
}
