package com.green.distribution.model;

import java.sql.Date;

import lombok.Data;

@Data
public class OrderApproval {
	private String orderNo;	// 주문번호
	private String buyerCd;	// 구매자 코드
	private String empCd;	// 직원코드
	private String reason;	// 사유
	private int amount;		// 총액
	private Date appDate;	// 승인일
	private String status;	// 상태
	private String del;		// 삭제
	private Date stateDate;	// 최종변경일
}
