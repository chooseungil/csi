package com.green.distribution.service;

import java.util.List;

import com.green.distribution.model.OrderProduct;

public interface OrderProductService {

	List<OrderProduct> orderList(OrderProduct orderProduct);

//	List<OrderProduct> orderList(OrderProduct order);

}
