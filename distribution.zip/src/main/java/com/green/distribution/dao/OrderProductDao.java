package com.green.distribution.dao;

import java.util.List;

import com.green.distribution.model.OrderProduct;

public interface OrderProductDao {

	List<OrderProduct> orderList(OrderProduct orderProduct);

//	List<OrderProduct> orderList(OrderProduct order);

}
